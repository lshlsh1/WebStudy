/*
 * 		ServletSample.java
 * 
 * */
package com.test.logic;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloReceive03Model extends HttpServlet
{

	public String helloName(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException
	{
		String result="";
		
		request.setCharacterEncoding("UTF-8");
		
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		
		request.setAttribute("firstName", firstName);
		request.setAttribute("lastName", lastName);
		
		result = "WEB-INF/view/HelloReceive03.jsp";
		
		return result;
	}

	
}
