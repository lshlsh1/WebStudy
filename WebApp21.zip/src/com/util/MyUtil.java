/*
 * 	MyUtil.java
 *  - 게시판 페이징 처리
 */

// check~!!!!
// 지금 같이 확인해보고자 하는 페이징 처리 기법은
// 다양한 방법들 중 한가지(그나마 쉬운 것을 골라...)이다.
// 학습을 마친 이후에... 꼭 추가적으로 개념을 정리하고 
// 확장시키고 다른 방법들도 찾아보고 공부해야 할 것이다

package com.util;

public class MyUtil
{
	// ■ 전체 페이지 수를 구하는 메소드
	// numPerPage : 한 페이지에 표시할 데이터(게시물)의 수
	// dataCount : 전체 데이터(게시물)의 수
	public int getPageCount(int numPerPage, int dataCount)
	{
		int pageCount = 0;
		
		pageCount = dataCount/numPerPage;
		
		// dataCount 32 numPerPage 10 이라고 가정했을 떄
		// 3개의 페이지 이후에 2개의 게시물을 게시하기위해 1장의 페이지가 더 필요하게 된다
		// 그러므로 dataCount % numPerPage != 0 일 경우 pageCount에 1 더해준다
		if(dataCount % numPerPage != 0)
			pageCount++;
		
		return pageCount;
	}
	
	// ■ 페이징 처리 기능의 메소드
	// current_page : 현재 표시할 페이지
	// total_page : 전체 페이지 수
	// list_url : 링크를 설정할 url
	public String pageIndexList(int current_page, int total_page, String list_url)
	{
		//실제 페이징을 저장할 StringBuffer 변수
		StringBuffer strList = new StringBuffer();
		
		int numPerBlock = 10;
		//-- 페이징 처리시 하단에 숫자를 10개씩 보여주겠다는 설정
		
		int currentPageSetup;
		//-- 현재 페이지(이페이지를 기준으로 보여주는 숫자가 달라져야 하기 때문)
		
		int page;
		int n;
		//-- 이전 페이지 블럭과 같은 처리에서 이동하기 위한 변수
		//	 (얼마만큼 이동해야 하는지...)
		
		// 페이징 처리가 별도로 필요하지 않은 경우
		//-- 데이터가 존재하지 않거나, 게시물이 한페이지를 채우지 못하는 경우는 별도의 페이징 처리를 할 필요가 없다.
		if(current_page ==0)
			return "";
		
		
		//페이지 요청을 처리하는 과정에서 URL 경로의 패턴에 대한 처리
		/*
		 	- List.jsp
		 	→ List.jsp  + 『?』
			- List.jsp → List.jsp?
		
			- List.jsp?키!=값1
			→ List.jsp?키!=값1 + 『&』
			- List.jsp?키!=값1 → List.jsp?키!=값1& 
			- List.jsp?키!=값1&키2=값2 → List.jsp?키!=값1&키2=값2&
		*/
		
		// url에서 ?가 있는지 확인 		// 링크 설정한 url에 ?가 들어있다면...
		if(list_url.indexOf("?") != -1 )
			list_url = list_url + "&";
		else							// 링크 설정한 url에 ?가 없으면...
			list_url = list_url + "?";
		//-- 예를들어, 검색값이 존재하면 이미 request 값에 searchKey 값과 searchValue 값이 들어있는 상황이므로
		//	 『&』를 붙여서 추가해주어야 한다.
		
		// 첫 페이지 번호 setup
		//currentPageSetup = 표시할 첫 페이지
		currentPageSetup = ( current_page / numPerBlock ) * numPerBlock;
		//-- 만약 현재 페이지가 5페이지이고 (curreng_page=5)
		//	 리스트 하단에 보여줄 페이지 갯수가 10이면 (numPerBlock=10)
		//	 『5/10 = 0』(몫만 취함) 이며... 여기에 10을 곱해도 『*10』 0이다
		//	 하지만 현재 페이지가 11페이지라면 (current_page=11)
		//	 『11/10 = 1』이며... 여기에 10을 곱하면 『*10』 10이다.
		//	 그러면 currentPageSetup은 10이 되는 것이다.
				
		if(current_page % numPerBlock == 0)
			currentPageSetup = currentPageSetup - numPerBlock;
		//-- 만약 위 처리에서(라인 80)
		//	 현재 페이지가 20페이지였다면 (current_page=20)
		//	 『20/10=2』이며... 여기에 10을 곱해서(『*10』) 20이 되는데
		// 	 이런 상황이라면 다시 10을 빼서 10으로 만들어준다.
		
		/*
		
		첫페이지
		setup
		
		0			 1  2  3  4  5  6  7  8  9 10
		10			11 12 13 14 15 16 17 18 19 20
		20			21 22 23 24 25 26 27 28 29 30
						:
						:
		
		*/
		
		
		// 1페이지
		//	총페이지가 numPerBlock보다 크면서 현재페이지가 0보다 클때 1로 돌아가는기
		if( ( total_page > numPerBlock ) && (currentPageSetup> 0 ) )
			strList.append(" <a href =' "+list_url +"pageNum=1'>1</a>");
		//-- list_url 은 전처리가 이미 끝난 상황이기 때문에
		//	 『....?』 상태 또는 『...?...&』 인 상태이다.
		//	 이로 인해 결과는 『...?pageNum=1』이거나
		//   『...&pageNum=1』가 되는 상황이다.
		
		// Prev
		// 현재페이지 - numPerBlock(10); 
		// n의 역할 내가 29에 머물고 있지만 19를 선택할 수 있도록 해당페이지만큼 앞의 페이지set을 보여줌
		n = current_page - numPerBlock;
		if ( ( total_page> numPerBlock) && (currentPageSetup >0 ) )
			strList.append("<a href='"+list_url+"pageNum="+n+"'>Prev</a>");
		//-- currentPageSetup 이 0보다 큰 경우는 이미 페이지가 10이상이라는 의미이며
		//   이 때 현재 페이지(current_page_가 11페이지 이상일 경우 『Prev』를 붙이기 위한 내용
		//	 『Prev』를 클릭할 경우
		//	  n 변수 페이지로 이동하는데 12에서 『Prev』할 경우 2페이지가 되고
		//	  22에서 『Prev』  에서 할 경우 12페이지가 될 수 있도록 처리하는 방식이다
		
		// 바로가기
		page = currentPageSetup + 1;
		//-- 『+1』을 하는 이유는 앞에서 currentPageSetup에서
		//	 10을 가져왔다면 10부터 시작하는 것이 아니라
		//	 바로가기 페이지는 11부터 시작해야하기 때문이다.
		
		
		while ( (page <= total_page ) && (page <= currentPageSetup + numPerBlock ) )
		{
			//내가 머물고 있는 페이지에 스타일 적용하기
			if( page == currentPageSetup )
				strList.append("<span style='color:orange; font-weight:bold;'>" + page + "</span>");
			else	//머물고있지 않은 페이지
				strList.append("<a href='"+list_url+"pageNum="+page+"'>"+ page + "</a>");	
			
			page++;
		}
		
		// Next
		n = current_page + numPerBlock;
		if( (total_page - currentPageSetup) > numPerBlock )
			strList.append("<a href='"+list_url+"pageNum="+n+"'>Next</a>");
		
		//마지막 페이지
		if( (total_page > numPerBlock) && ( (currentPageSetup + numPerBlock ) < total_page ) )
			strList.append("<a href='"+list_url+"pageNum="+total_page+"'>"+ total_page + "</a>");
				
		return strList.toString();
		
	}
	
}
