/*========================
	ServletSample.java
========================*/

package com.test.ajax;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Test03_me extends HttpServlet
{
	private static final long SerialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGetPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGetPost(request, response);
	}
	
	// 사용자 정의 메소드
	protected void doGetPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// 서블릿 관련 코딩
		String userId = request.getParameter("id");
		String result = "";
		
		/*
		//arrayList로 해결해보기!!
		int num=0;
		ArrayList<String> regId = new ArrayList<String>();
		regId.add("superman");
		regId.add("batman");
		regId.add("admin");
		
		for (int i = 0; i < regId.size() ; i++)
		{
			if(userId.equals(regId.get(i).toString()))
				num=1;
		
		if(num>0)
		{	
			result = "이미 존재하는 아이디입니다";
		}else
		{
			result = "아이디를 사용할 수 있습니다.";
		}
		*/
		
		String[] regId = {"superman", "batman", "admin"};
		int num=0;
		
		for (int i = 0; i < regId.length; i++)
		{
			if(userId.equals(regId[i].toString()))
				num=1;
		}
		
			if(num>0)
			{
				result = "이미 존재하는 아이디입니다";
			}else
			{
				result = "아이디를 사용할 수 있습니다.";
			}
		
		request.setAttribute("result", result);
		
		RequestDispatcher rd = request.getRequestDispatcher("Test03OK_me.jsp");
		rd.forward(request, response);
		
		
	}

}
