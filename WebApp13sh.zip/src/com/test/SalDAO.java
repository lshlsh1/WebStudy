package com.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.util.DBConn;

public class SalDAO
{
	private Connection conn;
	
	public SalDAO() throws ClassNotFoundException, SQLException
	{
		conn = DBConn.getConnection();
	}
	
	
	// 데이터 추가
	public int salAdd(SalDTO saldto) throws SQLException
	{
		int result = 0;
		
		String sql = "INSERT INTO SALGRADE(GRADE, LOSAL, HISAL) VALUES (?,?,?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, saldto.getSalGrade());
		pstmt.setInt(2, saldto.getSalLosal());
		pstmt.setInt(3, saldto.getSalHisal());
		
		result = pstmt.executeUpdate();
		
		pstmt.close();
		
		return result;
	}
	
	public int check(String grade) throws SQLException
	{
		int result = 0;
		
		String sql = "SELECT COUNT(*) AS COUNT FROM SALGRADE WHERE GRADE = ?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		
		pstmt.setString(1, grade);
		
		ResultSet rs = pstmt.executeQuery();
		
		while(rs.next())
		{
			result = rs.getInt("COUNT");
		}
		
		return result;
	}
	
	// 리스트 출력
	public ArrayList<SalDTO> salLists() throws SQLException
	{
		ArrayList<SalDTO> result = new ArrayList<SalDTO>();
		
		String sql = "SELECT GRADE, LOSAL, HISAL FROM SALGRADE";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		SalDTO saldto = null;
		while(rs.next())
		{
			saldto = new SalDTO();
			saldto.setSalGrade(rs.getString("GRADE"));
			saldto.setSalLosal(rs.getInt("LOSAL"));
			saldto.setSalHisal(rs.getInt("HISAL"));
			
			result.add(saldto);
		}
		rs.close();
		pstmt.close();
		
		return result;
	}
	
	// 카운트
	public int salCount() throws SQLException
	{
		int result = 0;
		String sql = "SELECT COUNT(*) AS COUNT FROM SALGRADE";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next())
			result = rs.getInt("COUNT");
		rs.close();
		pstmt.close();
		
		return result;
	}
	
	// 등급 검색
	public int grSearch(String grade) throws SQLException
	{
		int result = 0;
		
		String sql = "SELECT COUNT(*) AS COUNT FROM SALGRADE WHERE GRADE = ?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, grade);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next())
			result = rs.getInt("COUNT");
		rs.close();
		pstmt.close();
		
		return result;
	}
	
	// 검색
	public SalDTO salSearch(String grade) throws SQLException
	{
		SalDTO result = new SalDTO();
		
		String sql = "SELECT GRADE, LOSAL, HISAL FROM SALGRADE WHERE GRADE = ?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, grade);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{
			result.setSalGrade(rs.getString("GRADE"));
			result.setSalLosal(rs.getInt("LOSAL"));
			result.setSalHisal(rs.getInt("HISAL"));
		}
		rs.close();
		pstmt.close();
		
		return result;
	}
	
	// 수정
	public int salModify(SalDTO dto)
	{
		int result = 0;

		try
		{
			String sql = "UPDATE SALGRADE SET LOSAL=?, HISAL=? WHERE GRADE=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, dto.getSalLosal());
			pstmt.setInt(2, dto.getSalHisal());
			pstmt.setString(3, dto.getSalGrade());

			result = pstmt.executeUpdate();
			pstmt.close();
		} catch (SQLException e)
		{
			System.out.println(e.toString());
		}

		return result;
	}

	
	
	// 삭제
	public int salRemove(String GRADE)
	{
		int result = 0;

		try
		{
			String sql = "DELETE FROM SALGRADE WHERE GRADE = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, GRADE);
			pstmt.executeLargeUpdate();

			pstmt.close();
		} catch (SQLException e)
		{
			System.out.println(e.toString());
		}

		return result;

	}
	

	public void close() throws SQLException
	{
		DBConn.close();
	}
	
}



