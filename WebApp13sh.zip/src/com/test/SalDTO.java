package com.test;

public class SalDTO
{
	private String salGrade;
	private int salLosal, salHisal;
	
	
	public String getSalGrade()
	{
		return salGrade;
	}
	public void setSalGrade(String salGrade)
	{
		this.salGrade = salGrade;
	}
	public int getSalLosal()
	{
		return salLosal;
	}
	public void setSalLosal(int salLosal)
	{
		this.salLosal = salLosal;
	}
	public int getSalHisal()
	{
		return salHisal;
	}
	public void setSalHisal(int salHisal)
	{
		this.salHisal = salHisal;
	}	
}
