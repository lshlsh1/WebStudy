package com.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.util.DBConn;

public class DeptDAO
{
	Connection conn;
	
	public DeptDAO() throws ClassNotFoundException, SQLException
	{
		conn = DBConn.getConnection();
	}
	
	public int add(DeptDTO dto) throws SQLException
	{
		int result = 0;
		
		String sql = "INSERT INTO DEPT(DEPTNO, DNAME, LOC) VALUES(?, ?, ?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, dto.getDeptNo());
		pstmt.setString(1, dto.getdName());
		pstmt.setString(1, dto.getLoc());
		
		result = pstmt.executeUpdate();
		
		pstmt.close();
		
		return result;
	}
	
	public int modify(DeptDTO dto) throws SQLException
	{
		int result = 0;
		
		String sql = "UPDATE DEPT SET DNAME=?, LOC=? WHERE DEPTNO=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, dto.getdName());
		pstmt.setString(1, dto.getLoc());
		pstmt.setString(1, dto.getDeptNo());
		
		result = pstmt.executeUpdate();
		
		pstmt.close();
		
		return result;
	}
	
	public int remove(String deptNo) throws SQLException
	{
		int result = 0;
		
		String sql = "DELETE FROM DEPT WHERE DEPTNO=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, deptNo);
		
		result = pstmt.executeUpdate();
		
		pstmt.close();
		
		return result;
	}
	
	public int count() throws SQLException
	{
	   int result = 0;
	   
	   String sql = "SELECT COUNT(*) AS COUNT FROM DEPT";
	   
	   PreparedStatement pstmt = conn.prepareStatement(sql);
	   ResultSet rs = pstmt.executeQuery();
	   
	   while(rs.next())
	      result = rs.getInt("COUNT");
	   
	   
	   rs.close();
	   pstmt.close();
	   
	   return result;   
	}
	
	// 2. 부서 관리
	// select 결과 : DEPTNO, DNAME, LOC, 사원 수
	// 부서 별 사원수 관리 메소드
	public int count(String deptno) throws SQLException
	{
	   int result = 0;
	   
	   String sql = "SELECT COUNT(*) AS COUNT FROM DEPT WHERE DEPTNO=?";
	   
	   PreparedStatement pstmt = conn.prepareStatement(sql);
	   pstmt.setString(1, deptno);
	   ResultSet rs = pstmt.executeQuery();
	   
	   while(rs.next())
	      result = rs.getInt("COUNT");
	   
	   
	   rs.close();
	   pstmt.close();
	   
	   return result;   
	}
	
	public ArrayList<DeptDTO> lists() throws SQLException
	{
	   ArrayList<DeptDTO> result = new ArrayList<DeptDTO>();
	   
	   String sql = "SELECT DEPTNO, DNAME, LOC FROM DEPT ORDER BY DEPTNO";
	   
	   PreparedStatement pstmt = conn.prepareStatement(sql);
	   ResultSet rs = pstmt.executeQuery();
	   
	   while (rs.next())
	   {
	      DeptDTO dept = new DeptDTO();
	      dept.setDeptNo(rs.getString("DEPTNO"));
	      dept.setdName(rs.getString("DNAME"));
	      dept.setLoc(rs.getString("LOC"));
	      
	      result.add(dept);
	   }
	   
	   rs.close();
	   pstmt.close();
	   
	   return result;
	}
	
	public DeptDTO searchlist(String deptno) throws SQLException
	{
	   DeptDTO result = new DeptDTO();
	   
	   String sql = "SELECT DEPTNO, DNAME, LOC FROM DEPT WHERE DEPTNO=?";
	   PreparedStatement pstmt = conn.prepareStatement(sql);
	   pstmt.setString(1, deptno);
	   
	   ResultSet rs = pstmt.executeQuery();
	   while(rs.next())
	   {
	      result.setDeptNo(rs.getString("DEPNO"));
	      result.setdName(rs.getString("DNAME"));
	      result.setLoc(rs.getString("LOC"));
	      
	   }
	   
	   rs.close();
	   pstmt.close();
	   
	   return result;
	   
	}
	
	public void close() throws SQLException
	{
	   DBConn.close();
	}
}
