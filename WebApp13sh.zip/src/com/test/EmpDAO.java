package com.test;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.util.DBConn;

public class EmpDAO
{
	private Connection conn;
	
	public EmpDAO() throws ClassNotFoundException, SQLException
	{
		conn = DBConn.getConnection();
	}
	
	// 메소드 정의 (EMP - add)
	public int add(EmpDTO emp) throws SQLException
	{
		int result = 0;
		
		String sql = "INSERT INTO EMP(EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, DEPTNO) VALUES(?, ?, ?, ?, TO_DATE(?,'YYYY-MM-DD'),?, ?, ?)";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, emp.getEmpNo());
		pstmt.setString(2, emp.geteName());
		pstmt.setString(3, emp.getJob());
		pstmt.setString(4, emp.getMgr());
		pstmt.setString(5, emp.getHiredate());
		pstmt.setInt(6, emp.getSal());
		pstmt.setInt(7, emp.getComm());
		pstmt.setInt(8, emp.getDeptNo());
		
		result = pstmt.executeUpdate();
		pstmt.close();
		
		return result;
	}
	
	// 메소드 정의 (EMP - modify)
	public int modify(EmpDTO emp) throws SQLException
	{
		int result = 0;
		String sql = "UPDATE EMP SET ENAME=?, JOB=?, MGR=?, HIREDATE=TO_DATE(?,'YYYY-MM-DD'), SAL=?, COMM=?, DEPTNO=? WHERE EMPNO = ?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, emp.geteName());
		pstmt.setString(2, emp.getJob());
		pstmt.setString(3, emp.getMgr());
		pstmt.setString(4, emp.getHiredate());
		pstmt.setInt(5, emp.getSal());
		pstmt.setInt(6, emp.getComm());
		pstmt.setInt(7, emp.getDeptNo());
		pstmt.setString(8, emp.getEmpNo());
		
		result = pstmt.executeUpdate();
		pstmt.close();
		
		return result;
	}
	
	// 메소드 정의 (EMP - remove)
	public int remove(String empNo) throws SQLException
	{
		int result = 0;
		
		String sql = "DELETE FROM EMP WHERE EMPNO = ?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, empNo);
		
		result = pstmt.executeUpdate();
		
		return result;
	}
	
	
	// 카운트, 리스트, 검색(사원번호 기준)
	
	// 카운트
	public int count() throws SQLException
	{
		int result=0;
		
		String sql = "SELECT COUNT(*) AS COUNT FROM EMP";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next())
			result = rs.getInt("COUNT");
		
		rs.close();
		pstmt.close();
		
		return result;
	}
	
	public int count(String s) throws SQLException
	{
		int result=0;
		
		String sql = "SELECT COUNT(*) AS COUNT FROM VIEW_EMP WHERE EMPNO LIKE UPPER('%"+s+"%') OR ENAME LIKE UPPER('%"+s+"%') OR JOB LIKE UPPER('%"+s+"%') OR HIREDATE LIKE UPPER('%"+s+"%') OR DNAME LIKE UPPER('%"+s+"%') OR LOC LIKE UPPER('%"+s+"%')";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next())
			result = rs.getInt("COUNT");
		
		rs.close();
		pstmt.close();
		
		return result;
	}
	
	// 리스트
	public ArrayList<EmpDTO> lists() throws SQLException
	{
		ArrayList<EmpDTO> result = new ArrayList<EmpDTO>();
		
		String sql = "SELECT EMPNO, ENAME, JOB, HIREDATE, MGR, DEPTNO, DNAME, LOC, SAL, COMM FROM VIEW_EMP";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next())
		{
			EmpDTO emp = new EmpDTO();
			emp.setEmpNo(rs.getString("EMPNO"));
			emp.seteName(rs.getString("ENAME"));
			emp.setJob(rs.getString("JOB"));
			emp.setHiredate(rs.getString("HIREDATE"));
			emp.setMgr(rs.getString("MGR"));
			emp.setDeptNo(rs.getInt("DEPTNO"));
			emp.setdName(rs.getString("DNAME"));
			emp.setLoc(rs.getString("LOC"));
			emp.setSal(rs.getInt("SAL"));
			emp.setComm(rs.getInt("COMM"));
			
			result.add(emp);
		}
		
		rs.close();
		pstmt.close();
		
		return result;
	}
	
	public ArrayList<EmpDTO> lists(String str) throws SQLException
	{
		ArrayList<EmpDTO> result = new ArrayList<EmpDTO>();
		
		String sql = "SELECT EMPNO, ENAME, JOB, HIREDATE, MGR, DEPTNO, DNAME, LOC, SAL, COMM FROM VIEW_EMP ORDER BY "+str;
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery(sql);
		while (rs.next())
		{
			EmpDTO emp = new EmpDTO();
			emp.setEmpNo(rs.getString("EMPNO"));
			emp.seteName(rs.getString("ENAME"));
			emp.setJob(rs.getString("JOB"));
			emp.setHiredate(rs.getString("HIREDATE"));
			emp.setMgr(rs.getString("MGR"));
			emp.setDeptNo(rs.getInt("DEPTNO"));
			emp.setdName(rs.getString("DNAME"));
			emp.setLoc(rs.getString("LOC"));
			emp.setSal(rs.getInt("SAL"));
			emp.setComm(rs.getInt("COMM"));
			
			result.add(emp);
		}
		
		rs.close();
		pstmt.close();
		
		return result;
	}
	
	// 검색(사원번호 기준)
	public EmpDTO search(String empNo) throws SQLException
	{
		EmpDTO emp = new EmpDTO();
		
		String sql = "SELECT EMPNO, ENAME, JOB, HIREDATE, MGR, DEPTNO, DNAME, LOC, SAL, COMM FROM VIEW_EMP WHERE EMPNO=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, empNo);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next())
		{
			emp.setEmpNo(rs.getString("EMPNO"));
			emp.seteName(rs.getString("ENAME"));
			emp.setJob(rs.getString("JOB"));
			emp.setHiredate(rs.getString("HIREDATE"));
			emp.setMgr(rs.getString("MGR"));
			emp.setDeptNo(rs.getInt("DEPTNO"));
			emp.setdName(rs.getString("DNAME"));
			emp.setLoc(rs.getString("LOC"));
			emp.setSal(rs.getInt("SAL"));
			emp.setComm(rs.getInt("COMM"));
		}
		
		rs.close();
		pstmt.close();
		
		return emp;
	}
	
	public ArrayList<EmpDTO> searchList(String s) throws SQLException
	{
		ArrayList<EmpDTO> result = new ArrayList<EmpDTO>();
				
		String sql = "SELECT EMPNO, ENAME, JOB, HIREDATE, MGR, DEPTNO, DNAME, LOC, SAL, COMM FROM VIEW_EMP WHERE EMPNO LIKE UPPER('%"+s+"%') OR ENAME LIKE UPPER('%"+s+"%') OR JOB LIKE UPPER('%"+s+"%') OR HIREDATE LIKE UPPER('%"+s+"%') OR DNAME LIKE UPPER('%"+s+"%') OR LOC LIKE UPPER('%"+s+"%')";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery(sql);
		while (rs.next())
		{
			EmpDTO emp = new EmpDTO();
			emp.setEmpNo(rs.getString("EMPNO"));
			emp.seteName(rs.getString("ENAME"));
			emp.setJob(rs.getString("JOB"));
			emp.setHiredate(rs.getString("HIREDATE"));
			emp.setMgr(rs.getString("MGR"));
			emp.setDeptNo(rs.getInt("DEPTNO"));
			emp.setdName(rs.getString("DNAME"));
			emp.setLoc(rs.getString("LOC"));
			emp.setSal(rs.getInt("SAL"));
			emp.setComm(rs.getInt("COMM"));
			
			result.add(emp);
		}
		
		rs.close();
		pstmt.close();
		
		return result;
	}
	
	public int getDeptNo(String dName) throws SQLException
	{
		int result = 0;
		
		String sql = "SELECT DEPTNO FROM DEPT WHERE DNAME=?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, dName);
		ResultSet rs = pstmt.executeQuery();
		
		while(rs.next())
			result = rs.getInt(1);

		rs.close();
		pstmt.close();
		
		return result;
	}
	
	public int getdName(String dName) throws SQLException
	{
		int result = 0;
		
		String sql = "SELECT DEPTNO FROM DEPT WHERE DNAME=?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, dName);
		ResultSet rs = pstmt.executeQuery();
		
		while(rs.next())
			result = rs.getInt(1);

		rs.close();
		pstmt.close();
		
		return result;
	}
	
	// 데이터베이스 연결 종료
	public void close() throws SQLException
	{
		DBConn.close();
	}
	
	
}
