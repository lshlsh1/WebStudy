function myMenu(status)
{
	var menu = document.getElementById("menuTable");
	
	if(status==1)
	{
		menu.style.display = "block";
	}else
	{
		menu.style.display = "none";
	}
	
	
}
	