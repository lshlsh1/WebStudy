alert(message);

