package com.test;

public class DeptEmpDTO
{
	private String empNo, eName, job, mgr, hiredate, dName, loc, deptNo;
	private int salGrade, sal, comm;
	
	
	public String getEmpNo()
	{
		return empNo;
	}
	public void setEmpNo(String empNo)
	{
		this.empNo = empNo;
	}
	public String geteName()
	{
		return eName;
	}
	public void seteName(String eName)
	{
		this.eName = eName;
	}
	public String getJob()
	{
		return job;
	}
	public void setJob(String job)
	{
		this.job = job;
	}
	public String getMgr()
	{
		return mgr;
	}
	public void setMgr(String mgr)
	{
		this.mgr = mgr;
	}
	public String getHiredate()
	{
		return hiredate;
	}
	public void setHiredate(String hiredate)
	{
		this.hiredate = hiredate;
	}
	public String getdName()
	{
		return dName;
	}
	public void setdName(String dName)
	{
		this.dName = dName;
	}
	public String getLoc()
	{
		return loc;
	}
	public void setLoc(String loc)
	{
		this.loc = loc;
	}
	public String getDeptNo()
	{
		return deptNo;
	}
	public void setDeptNo(String deptNo)
	{
		this.deptNo = deptNo;
	}
	public int getSalGrade()
	{
		return salGrade;
	}
	public void setSalGrade(int salGrade)
	{
		this.salGrade = salGrade;
	}
	public int getSal()
	{
		return sal;
	}
	public void setSal(int sal)
	{
		this.sal = sal;
	}
	public int getComm()
	{
		return comm;
	}
	public void setComm(int comm)
	{
		this.comm = comm;
	}

	
	
}
