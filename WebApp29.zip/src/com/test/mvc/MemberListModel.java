package com.test.mvc;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.DBConn;

public class MemberListModel
{
	public String getList(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException
	{
		String result = "";
		
		MemberDAO dao = new MemberDAO();
		ArrayList<MemberDTO> dto = new ArrayList<MemberDTO>();
		dto = dao.lists();
		request.setAttribute("arr", dto);
		DBConn.close();		
		
		result = "WEB-INF/view/MemberList.jsp";
		
		return result;
	
	}
	
}
