package com.test.mvc;

public class MemberInsertFormModel
{
	
	

}
