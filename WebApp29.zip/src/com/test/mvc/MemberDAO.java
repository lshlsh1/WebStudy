package com.test.mvc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.util.DBConn;

public class MemberDAO
{
	//데이터 입력
	private Connection conn;
	
	public MemberDAO() throws ClassNotFoundException, SQLException
	{
		conn = DBConn.getConnection();
	}
	
	public int insertData(MemberDTO dto) throws SQLException
	{
		int result = 0;
		
		String sql = "INSERT INTO TBL_MEMBERLIST(ID, PW, NAME, TEL, EMAIL) VALUES(?, ?, ?, ?, ?)";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, dto.getId());
		pstmt.setString(2, dto.getPwd());
		pstmt.setString(3, dto.getName());
		pstmt.setString(4, dto.getTel());
		pstmt.setString(5, dto.getEmail());
		
		result = pstmt.executeUpdate();

		pstmt.close();
		
		return result;
	}
	
	//데이터 출력
	public ArrayList<MemberDTO> lists()
	{
		ArrayList<MemberDTO> result = new ArrayList<MemberDTO>();
		
		String sql = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try
		{
			sql= "SELECT ID, PW, NAME, TEL, EMAIL FROM TBL_MEMBERLIST";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next())
			{
				MemberDTO dto = new MemberDTO();
				dto.setId(rs.getString("ID"));
				dto.setPwd(rs.getString("PW"));
				dto.setName(rs.getString("NAME"));
				dto.setTel(rs.getString("TEL"));
				dto.setEmail(rs.getString("EMAIL"));
				
				result.add(dto);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		
		return result;
		
	}
	
	public void close() throws SQLException
	{
		DBConn.close();
	}
}
