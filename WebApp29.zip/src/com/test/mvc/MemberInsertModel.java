package com.test.mvc;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MemberInsertModel
{
	
	public String insertModel(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException, UnsupportedEncodingException 
	{ 
		request.setCharacterEncoding("UTF-8");
		
		String userName = request.getParameter("userName"); 
		String userPwd = request.getParameter("userPwd"); 
		String userId = request.getParameter("userId"); 
		String userTel = request.getParameter("userTel"); 
		String userEmail = request.getParameter("userEmail");
	
		MemberDTO dto = new MemberDTO(); 
		MemberDAO dao = new MemberDAO();
	
		dto.setName(userName); 
		dto.setPwd(userPwd); 
		dto.setId(userId);
		dto.setTel(userTel); 
		dto.setEmail(userEmail);
		
		request.setAttribute("dto", dto);
		
		return "WEB-INF/view/MemberInsert.jsp"; 
	
	}
	
}
